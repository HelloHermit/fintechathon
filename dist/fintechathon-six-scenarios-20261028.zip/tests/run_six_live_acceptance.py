"""Independent frozen real-model acceptance; run explicitly, never by discovery.

Uses only public BankService, ModelClient and IsolatedExecutor contracts.
No automatic retry, guessed candidate repair, normal database, or secret output.
"""
from __future__ import annotations

import argparse
from contextlib import closing
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
if ROOT.name == "tests":
    ROOT = ROOT.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.bank import BankService
from src.isolation import IsolatedExecutor
from src.model import ModelClient, ModelError


SHANGHAI = timezone(timedelta(hours=8))
NOW = datetime(2026, 10, 27, 10, 0, tzinfo=SHANGHAI)
DATE = "2026-11-01"
TABLES = ("accounts", "subscriptions", "transactions", "transfers", "cards", "budgets", "orders")
PRODUCTS = {
    "p-cash": ("模拟活期A", "low", 1, "immediate", 180),
    "p-flex": ("模拟灵活B", "medium", 7, "flexible", 220),
    "p-steady": ("模拟稳健C", "medium", 90, "locked", 260),
    "p-growth": ("模拟成长D", "high", 365, "locked", 420),
}
SERVICE_ROWS = {"flower-basic": ("模拟鲜花", 12900), "cake-basic": ("模拟蛋糕", 9900)}
PLAN = [
    ("catalog", "query_services", {}, []),
    ("pay", "place_order", {"budget_id": "birthday", "service_id": "flower-basic", "event_date": DATE, "card_id": "card-alice-main"}, ["catalog"]),
    ("budget", "query_budgets", {"budget_id": "birthday"}, ["pay"]),
    ("orders", "query_orders", {"budget_id": "birthday"}, ["budget"]),
    ("balance", "query_balance", {}, ["orders"]),
    ("bill", "analyze_bills", {}, ["balance"]),
]
PLAN_TEXT = (
    "请建立六个静态节点的计划，按以下节点编号和依赖办理："
    "节点catalog查询服务价目；节点pay依赖catalog，从已有预算birthday，"
    "为活动日期2026-11-01用卡片card-alice-main购买服务flower-basic鲜花；"
    "节点budget依赖pay，查询预算birthday；节点orders依赖budget，查询预算birthday的订单；"
    "节点balance依赖orders，查询我的全部账户余额；节点bill依赖balance，查询我的本月账单。"
)


class AcceptanceFailure(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def require(condition, code):
    if not condition:
        raise AcceptanceFailure(code)


def exact(actual, expected):
    """Unlike Python equality, bool can never satisfy an expected integer."""
    if type(actual) is not type(expected):
        return False
    if isinstance(expected, dict):
        return set(actual) == set(expected) and all(exact(actual[key], value) for key, value in expected.items())
    if isinstance(expected, list):
        return len(actual) == len(expected) and all(exact(a, b) for a, b in zip(actual, expected))
    return actual == expected


def safe(value, depth=0):
    """Only sanitized diagnostics leave memory; credentials never become evidence."""
    if depth > 14:
        return "[DEPTH_LIMIT]"
    if isinstance(value, dict):
        output = {}
        for key, item in list(value.items())[:100]:
            key = str(key)[:80]
            if key.lower() == "token" or any(word in key.lower() for word in ("confirmation_code", "recovery_code", "password", "secret", "access_token", "refresh_token", "api_token", "bearer_token", "api_key", "authorization")):
                output[key] = "[REDACTED]"
            else:
                output[key] = safe(item, depth + 1)
        return output
    if isinstance(value, (tuple, list)):
        return [safe(item, depth + 1) for item in value[:100]]
    if isinstance(value, str):
        if re.search(r"(?i)bearer\s|sk-[A-Za-z0-9]|api[_ -]?key\s*[:=]|password\s*[:=]|totp[_ -]?secret\s*[:=]", value):
            return "[SENSITIVE_TEXT_OMITTED]"
        value = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", value[:16000])
        return re.sub(r"(?<![A-Za-z0-9])[0-9]{6}(?![A-Za-z0-9])", "[REDACTED]", value)
    if type(value) in (int, bool, float) or value is None:
        return value
    return "[UNSUPPORTED_VALUE]"


def query(database, sql, parameters=()):
    with closing(sqlite3.connect(str(database))) as connection:
        connection.row_factory = sqlite3.Row
        return [dict(row) for row in connection.execute(sql, parameters)]


def business(database):
    return {table: sorted(query(database, "SELECT * FROM " + table), key=repr) for table in TABLES}


def ledger(database):
    accounts = query(database, "SELECT account_id,user_id,balance_cents FROM accounts ORDER BY account_id")
    budgets = query(database, "SELECT * FROM budgets WHERE user_id='alice' ORDER BY budget_id")
    reserved = {}
    for budget in budgets:
        reserved[budget["account_id"]] = reserved.get(budget["account_id"], 0) + budget["remaining_cents"]
    balances = [{**row, "reserved_cents": reserved.get(row["account_id"], 0),
                 "available_cents": row["balance_cents"] - reserved.get(row["account_id"], 0)} for row in accounts]
    transfers = query(database, "SELECT * FROM transfers WHERE user_id='alice' AND status='success' AND shanghai_date=?", (NOW.date().isoformat(),))
    orders = query(database, "SELECT * FROM orders WHERE user_id='alice' ORDER BY order_id")
    daily = sum(row["amount_cents"] for row in transfers) + sum(row["amount_cents"] for row in orders if row["status"] == "paid" and row["shanghai_date"] == NOW.date().isoformat())
    expense = query(database, "SELECT COALESCE(SUM(amount_cents),0) AS total FROM transactions WHERE user_id='alice' AND status='success' AND kind='expense' AND occurred_at>=? AND occurred_at<=?", (NOW.replace(day=1, hour=0, minute=0, second=0).isoformat(), NOW.isoformat()))[0]["total"]
    return {"accounts": balances, "budgets": budgets, "orders": orders, "daily_outgoing_cents": daily,
            "actual_expense_cents": expense,
            "cards": query(database, "SELECT * FROM cards WHERE user_id='alice' ORDER BY card_id"),
            "subscriptions": query(database, "SELECT * FROM subscriptions WHERE user_id='alice' ORDER BY subscription_id")}


def balance_of(state, account_id):
    matches = [row for row in state["accounts"] if row["account_id"] == account_id]
    require(len(matches) == 1, "account_fixture_missing")
    return matches[0]


def budget_of(state, budget_id):
    matches = [row for row in state["budgets"] if row["budget_id"] == budget_id]
    require(len(matches) == 1, "budget_fixture_missing")
    return matches[0]


def card_of(state, card_id):
    matches = [row for row in state["cards"] if row["card_id"] == card_id]
    require(len(matches) == 1, "card_fixture_missing")
    return matches[0]


class ObservedModel:
    def __init__(self, harness):
        self.harness = harness

    def propose(self, text, context):
        harness = self.harness
        call_number = harness.call_count() + 1
        require(call_number <= harness.max_calls, "live_call_budget_exhausted")
        harness.emit("model_call_started", call_number=call_number, group=harness.group, text=text)
        client = None
        result = None
        error = None
        try:
            def parse(raw):
                return harness.executor.execute("parse_candidate", {"text": raw}, request_id="live-parser-" + str(call_number))
            client = ModelClient.from_environment(candidate_parser=parse)
            result = client.propose(text, context)
            return result
        except Exception as exception:
            error = {"type": type(exception).__name__}
            if isinstance(exception, ModelError):
                error.update({"code": exception.code, "http_status": exception.http_status})
            raise
        finally:
            metadata = {"model_alias": getattr(client, "model_name", None),
                        "reported_model": getattr(client, "last_reported_model", None),
                        "usage": getattr(client, "last_usage", None),
                        "request_attempted": getattr(client, "last_request_attempted", None),
                        "requested_max_tokens": 1200, "temperature": "not_explicitly_set",
                        "deepseek_thinking": "disabled", "cost": "unknown"}
            harness.emit("model_call_finished", call_number=call_number, group=harness.group,
                         metadata=metadata, candidate=result, error=error)


class Harness:
    def __init__(self, directory, runtime, max_calls):
        self.directory = Path(directory)
        self.runtime = Path(runtime).resolve()
        self.max_calls = max_calls
        self.group = None
        self.executor = None
        self.bank = None
        self.database = None
        self.codes = set()
        self.journal = self.directory / "events.jsonl"

    def events(self):
        if not self.journal.exists():
            return []
        with self.journal.open("r", encoding="utf-8") as handle:
            return [json.loads(line) for line in handle if line.strip()]

    def call_count(self):
        return sum(row.get("event") == "model_call_started" for row in self.events())

    def emit(self, event, **details):
        record = safe({"event": event, "group": self.group, **details})
        with self.journal.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
            handle.flush()

    def ensure_executor(self):
        if self.executor is None:
            self.executor = IsolatedExecutor(str(self.runtime), str(self.directory / "monitor.sqlite"))

    def start_bank(self, group, *, existing=False):
        self.group = group
        self.ensure_executor()
        self.database = self.directory / ("group-" + str(group) + ".sqlite")
        require(self.database.exists() == existing, "database_reuse_boundary")
        self.bank = BankService(str(self.database), user_id="alice", clock=lambda: NOW, executor=self.executor)
        self.emit("group_opened", existing_database=existing, state=ledger(self.database))

    def close_bank(self):
        if self.bank is not None:
            self.bank.close()
            self.bank = None

    def close(self):
        self.close_bank()
        if self.executor is not None:
            self.executor.close()
            self.executor = None

    def text(self, text):
        before = ledger(self.database)
        self.emit("human_input", text=text, before=before)
        response = self.bank.handle_text(text, ObservedModel(self))
        self.emit("code_response", response=response, after=ledger(self.database))
        return response

    def status(self, response, expected):
        require(response.get("status") == expected, "unexpected_status_" + expected)

    def green(self, response, intent):
        self.status(response, "success")
        require(response.get("intent") == intent and response.get("tier") == "green", "unexpected_green_intent_or_tier")

    def pending_gate(self, response, intent, params):
        self.status(response, "pending")
        require(response.get("tier") == "yellow" and response.get("intent") == intent, "wrong_yellow_intent_or_tier")
        operation = response.get("operation", {})
        require(operation.get("user_id") == "alice" and operation.get("simulated") is True, "operation_identity_or_simulation")
        require(operation.get("intent") == intent and exact(operation.get("params"), params), "operation_exact_params_mismatch")
        require(isinstance(operation.get("impact"), str) and bool(operation["impact"]), "operation_impact_missing")
        request_id = response.get("request_id")
        require(isinstance(request_id, str) and re.fullmatch(r"[A-Za-z0-9_-]{1,128}", request_id) is not None, "invalid_request_id")
        code = response.get("confirmation_code")
        require(isinstance(code, str) and re.fullmatch(r"[0-9]{6}", code) is not None, "invalid_confirmation_code")
        expiry = datetime.fromisoformat(response["expires_at"])
        require(expiry.tzinfo is not None and NOW < expiry <= NOW + timedelta(minutes=5), "invalid_confirmation_lifetime")
        state = ledger(self.database)
        if intent == "transfer":
            for key, expected in (("target_name", "小王"), ("target_account_id", "bob-main"),
                                  ("amount_cents", params["amount_cents"]), ("daily_outgoing_after_cents", params["amount_cents"])):
                require(exact(operation.get(key), expected), "transfer_operation_" + key)
            require(state["daily_outgoing_cents"] == 0, "transfer_expected_daily_zero")
            require(balance_of(state, params["account_id"])["available_cents"] >= params["amount_cents"], "transfer_available_balance")
        elif intent == "reserve_budget":
            require(not any(row["budget_id"] == params["budget_id"] for row in state["budgets"]), "reserve_id_already_exists")
            account = balance_of(state, params["account_id"])
            require(account["user_id"] == "alice" and account["balance_cents"] == 1000000 and account["available_cents"] == 1000000, "reserve_source_facts")
        elif intent == "apply_virtual_card":
            require(params == {"account_id": "alice-main"} and balance_of(state, "alice-main")["balance_cents"] == 1000000, "virtual_card_source_facts")
            require(len(state["cards"]) == 1, "virtual_card_count_before")
        elif intent == "set_card_limit":
            card = card_of(state, params["card_id"])
            require((card["user_id"], card["account_id"], card["status"], card["daily_limit_cents"]) == ("alice", "alice-main", "active", 100000), "set_limit_original_binding")
        elif intent == "query_subscriptions":
            require("subscriptions" not in response.get("data", {}) and "subscriptions" not in operation, "subscriptions_leaked_before_confirm")
        elif intent == "cancel_subscription":
            require(params == {"subscription_id": "sub-video"} and operation.get("target_name") == "视频会员", "subscription_target_binding")
            sub = next((row for row in state["subscriptions"] if row["subscription_id"] == "sub-video"), None)
            require(sub is not None and sub["status"] == "active" and sub["amount_cents"] == 2990, "subscription_original_state")
        elif intent == "place_order":
            require(exact(params, PLAN[1][2]), "order_must_match_frozen_payment")
            self.check_living_state(paid=False)
            card = card_of(state, "card-alice-main")
            require((card["user_id"], card["account_id"], card["status"], card["daily_limit_cents"]) == ("alice", "alice-main", "active", 100000), "order_card_binding")
            service = query(self.database, "SELECT service_id,name,price_cents FROM service_catalog WHERE service_id='flower-basic'")
            require(service == [{"service_id": "flower-basic", "name": "模拟鲜花", "price_cents": 12900}], "order_code_price_binding")
        else:
            raise AcceptanceFailure("unexpected_confirmation_tool")
        self.codes.add(code)
        self.emit("confirmation_gate_passed", intent=intent, request_id=request_id, params=params, trusted_facts=state)
        return code

    def confirm(self, response, intent, params):
        code = self.pending_gate(response, intent, params)
        result = self.bank.confirm(response["request_id"], code)
        self.emit("fixed_confirmation_result", request_id=response["request_id"], response=result, after=ledger(self.database))
        self.status(result, "success")
        require(result.get("intent") == intent, "confirmed_wrong_tool")
        self.require_receipt(response["request_id"])
        return result

    def require_receipt(self, request_id):
        rows = query(self.directory / "monitor.sqlite", "SELECT status,reason,metadata_json FROM isolation_audit WHERE request_id=? AND event='finished'", (request_id,))
        require(bool(rows), "missing_actual_docker_receipt")
        for row in rows:
            metadata = json.loads(row["metadata_json"])
            require(row["status"] == "success", "unsuccessful_docker_receipt")
            require(metadata.get("mechanism") == "docker-linux-readonly-v2", "wrong_isolation_mechanism")
            require(metadata.get("cleanup_complete") is True and metadata.get("container_removed") is True, "docker_cleanup_not_complete")
            require(metadata.get("container_running_after") is False and metadata.get("container_pid_after") == 0, "docker_still_running")

    def require_unchanged(self, before):
        require(exact(business(self.database), before), "unexpected_business_mutation")

    def check_budget(self, budget_id, remaining, spent=0, released=0):
        row = budget_of(ledger(self.database), budget_id)
        require((row["remaining_cents"], row["spent_cents"], row["released_cents"]) == (remaining, spent, released), "budget_amounts_mismatch")
        require(row["amount_cents"] == remaining + spent + released, "budget_invariant_broken")

    def check_living_state(self, *, paid):
        state = ledger(self.database)
        account = balance_of(state, "alice-main")
        require(account["balance_cents"] == (987100 if paid else 1000000), "living_cash_mismatch")
        require(account["reserved_cents"] == (7100 if paid else 20000) and account["available_cents"] == 980000, "living_available_mismatch")
        self.check_budget("birthday", 7100 if paid else 20000, 12900 if paid else 0)
        require(len(state["orders"]) == (1 if paid else 0), "living_order_count")
        require(state["actual_expense_cents"] == (18870 if paid else 5970), "living_bill_mismatch")
        require(state["daily_outgoing_cents"] == (12900 if paid else 0), "living_daily_mismatch")
        require(query(self.database, "SELECT COUNT(*) AS count FROM transfers")[0]["count"] == 0, "living_unexpected_transfer")

    def plan_gate(self, plan):
        require(plan.get("user_id") == "alice", "plan_wrong_owner")
        steps = plan.get("steps", [])
        require(len(steps) == len(PLAN), "plan_node_count")
        for step, (node_id, intent, params, dependencies) in zip(steps, PLAN):
            require(step.get("id") == node_id and step.get("intent") == intent, "plan_node_identity")
            snapshot_params = params
            if node_id == "bill":
                # RECOVERY_API resolves default dates in persisted/reviewed facts.
                # The original human/model input remains the frozen empty object.
                require(exact(step.get("input_params"), {}), "plan_bill_original_input_params")
                snapshot_params = {"start_date": NOW.replace(day=1).date().isoformat(),
                                   "end_date": NOW.date().isoformat()}
            require(exact(step.get("params"), snapshot_params) and exact(step.get("depends_on"), dependencies), "plan_static_parameters_or_dependencies")

    def finish_group(self):
        self.check_no_persisted_codes()
        self.emit("group_passed", final=ledger(self.database))
        self.close_bank()

    def check_no_persisted_codes(self):
        for table in ("audit_log", "requests", "recovery_plans"):
            serialized = json.dumps(query(self.database, "SELECT * FROM " + table), ensure_ascii=False, default=str)
            require(not any(code in serialized for code in self.codes), "credential_found_in_persistent_record")
        self.codes.clear()

    def run_group(self, group):
        self.start_bank(group)
        self.emit("group_started")
        try:
            getattr(self, "group_" + str(group))()
            self.finish_group()
        finally:
            self.close_bank()

    def group_1(self):
        before = business(self.database)
        response = self.text("查询我的模拟理财产品。")
        self.green(response, "query_investments")
        actual = {row["product_id"]: tuple(row[key] for key in ("name", "risk_level", "min_days", "liquidity", "illustrative_annual_rate_bps")) for row in response["data"]["products"]}
        require(actual == PRODUCTS, "investment_catalog_mismatch")
        self.require_receipt(response["request_id"])
        response = self.text("比较理财产品p-growth和p-cash，按这个顺序。")
        self.green(response, "compare_investments")
        require([row["product_id"] for row in response["data"]["products"]] == ["p-growth", "p-cash"], "investment_comparison_order")
        self.require_receipt(response["request_id"])
        response = self.text("匹配理财产品，最高风险medium，持有期限90天，流动性要求flexible。")
        self.green(response, "match_investments")
        require([row["product_id"] for row in response["data"]["products"]] == ["p-cash", "p-flex"], "investment_matching_conditions")
        require(exact(response["data"]["criteria"], {"risk_level": "medium", "horizon_days": 90, "liquidity": "flexible"}), "investment_matching_criteria")
        self.require_receipt(response["request_id"])
        self.require_unchanged(before)

    def group_2(self):
        response = self.text("查询我的模拟卡片。")
        self.green(response, "query_cards")
        require([row["card_id"] for row in response["data"]["cards"]] == ["card-alice-main"], "card_query_ownership")
        self.require_receipt(response["request_id"])
        before = business(self.database)
        pending = self.text("从我的主账户申请一张虚拟卡。")
        self.require_unchanged(before)
        result = self.confirm(pending, "apply_virtual_card", {"account_id": "alice-main"})
        card = result["data"]["card"]
        require(isinstance(card["card_id"], str) and re.fullmatch(r"sim-card-[a-p]+", card["card_id"]) is not None, "virtual_card_nonpayment_identifier")
        require((card["user_id"], card["account_id"], card["kind"], card["status"]) == ("alice", "alice-main", "virtual", "active"), "virtual_card_saved_binding")
        require(len(ledger(self.database)["cards"]) == 2, "virtual_card_not_saved_once")
        pending = self.text("将卡片card-alice-main的每日交易限额修改为200元。")
        self.confirm(pending, "set_card_limit", {"card_id": "card-alice-main", "daily_limit_cents": 20000})
        state = ledger(self.database)
        require(card_of(state, "card-alice-main")["daily_limit_cents"] == 20000, "card_limit_not_saved")
        require(balance_of(state, "alice-main")["balance_cents"] == 1000000 and not state["orders"], "card_operation_created_money")

    def group_3(self):
        response = self.text("查询我的本月实际账单。")
        self.green(response, "analyze_bills")
        require(exact(response["data"]["actual_expense_cents"], 5970), "baseline_bill_mismatch")
        self.require_receipt(response["request_id"])
        pending = self.text("从我的主账户给已登记的联系人小王转100元。")
        require(balance_of(ledger(self.database), "alice-main")["balance_cents"] == 1000000, "transfer_before_confirmation")
        result = self.confirm(pending, "transfer", {"account_id": "alice-main", "contact_id": "wang", "amount_cents": 10000})
        state = ledger(self.database)
        require(balance_of(state, "alice-main")["balance_cents"] == 990000 and balance_of(state, "bob-main")["balance_cents"] == 110000, "transfer_balances")
        require(exact(result["data"]["daily_outgoing_cents"], 10000), "transfer_daily_total")
        require(query(self.database, "SELECT COUNT(*) AS count FROM transfers WHERE status='success'")[0]["count"] == 1, "transfer_not_exactly_once")

    def group_4(self):
        first = self.confirm(self.text("查询我的订阅和代扣。"), "query_subscriptions", {})
        require(exact(first["data"]["future_expected_cents"], 5970), "subscription_baseline_future")
        result = self.confirm(self.text("取消我的视频会员，订阅编号sub-video。"), "cancel_subscription", {"subscription_id": "sub-video"})
        require(result.get("status") == "success", "subscription_cancel_failed")
        second = self.confirm(self.text("再查询我的订阅和代扣。"), "query_subscriptions", {})
        require(exact(second["data"]["future_expected_cents"], 2980), "subscription_cancel_future")
        state = ledger(self.database)
        require(next(row for row in state["subscriptions"] if row["subscription_id"] == "sub-video")["status"] == "cancelled", "subscription_not_saved")
        require(state["actual_expense_cents"] == 5970 and balance_of(state, "alice-main")["balance_cents"] == 1000000, "subscription_deleted_history_or_refunded")

    def group_5(self):
        before = business(self.database)
        count = query(self.database, "SELECT COUNT(*) AS count FROM requests")[0]["count"]
        response = self.text("保留生日预算200元，预算编号birthday。")
        self.status(response, "rejected")
        require(response.get("reason") == "clarification", "budget_missing_fields_not_clarified")
        require(query(self.database, "SELECT COUNT(*) AS count FROM requests")[0]["count"] == count, "clarification_created_business_request")
        self.require_unchanged(before)
        pending = self.text("从我的主账户，活动日期2026-11-01。")
        self.confirm(pending, "reserve_budget", {"budget_id": "birthday", "account_id": "alice-main", "event_date": DATE, "amount_cents": 20000})
        self.check_living_state(paid=False)
        before = business(self.database)
        response = self.text("帮我买鲜花。")
        self.status(response, "rejected")
        require(response.get("reason") == "clarification", "new_order_guessed_old_budget_or_date")
        self.require_unchanged(before)

    def group_6(self):
        before = business(self.database)
        cases = [("从我的主账户申购理财产品p-cash，金额100元。", "purchase_investment"),
                 ("从我的主账户赎回理财产品p-cash，金额100元。", "redeem_investment"),
                 ("挂失我的卡片card-alice-main。", "report_card_lost"),
                 ("解挂我的卡片card-alice-main。", "restore_card")]
        for text, intent in cases:
            response = self.text(text)
            self.status(response, "rejected")
            require(response.get("intent") == intent and response.get("tier") == "red", "red_operation_not_identified_or_refused")
            require("confirmation_code" not in response, "red_operation_has_yellow_code")
            self.require_unchanged(before)

    def group_7(self):
        before = business(self.database)
        response = self.text("请于2026-11-01自动联系商户购买鲜花，届时再付款。")
        require(response.get("status") == "rejected", "scheduler_request_silently_changed_to_supported_action")
        require("confirmation_code" not in response and "operation" not in response, "scheduler_created_authorization")
        self.require_unchanged(before)

    def group_8(self):
        pending = self.text("从我的主账户保留预算budgetLimit，金额400元，活动日期2026-11-01。")
        self.confirm(pending, "reserve_budget", {"budget_id": "budgetLimit", "account_id": "alice-main", "event_date": DATE, "amount_cents": 40000})
        pending = self.text("将卡片card-alice-main的每日交易限额修改为100元。")
        self.confirm(pending, "set_card_limit", {"card_id": "card-alice-main", "daily_limit_cents": 10000})
        before = business(self.database)
        response = self.text("从预算budgetLimit为活动日期2026-11-01用卡片card-alice-main购买服务flower-basic鲜花。")
        self.status(response, "rejected")
        require(response.get("intent") == "place_order", "card_limit_rejection_did_not_reach_order")
        self.require_unchanged(before)
        pending = self.text("从我的账户alice-savings给已登记联系人小王转900元。")
        self.confirm(pending, "transfer", {"account_id": "alice-savings", "contact_id": "wang", "amount_cents": 90000})
        before = business(self.database)
        response = self.text("不使用卡片，从预算budgetLimit为活动日期2026-11-01购买服务flower-basic鲜花。")
        self.status(response, "rejected")
        require(response.get("intent") == "place_order" and response.get("tier") == "red", "cross_account_combined_limit_not_red")
        self.require_unchanged(before)
        state = ledger(self.database)
        self.check_budget("budgetLimit", 40000)
        require(not state["orders"] and state["daily_outgoing_cents"] == 90000, "rejected_order_has_partial_effect")

    def prepare_group_9(self):
        self.start_bank(9)
        self.emit("group_started", phase="real_child_prepare")
        pending = self.text("从我的主账户保留预算birthday，金额200元，活动日期2026-11-01。")
        self.confirm(pending, "reserve_budget", {"budget_id": "birthday", "account_id": "alice-main", "event_date": DATE, "amount_cents": 20000})
        response = self.text(PLAN_TEXT)
        self.pending_gate(response, "place_order", PLAN[1][2])
        require(isinstance(response.get("plan_id"), str), "living_dag_not_created")
        plan = self.bank.get_plan(response["plan_id"])["plan"]
        self.plan_gate(plan)
        require(plan["steps"][0]["status"] == "success" and plan["steps"][1]["status"] == "pending", "living_dag_did_not_stop_for_confirmation")
        require(all(step["status"] == "not_started" for step in plan["steps"][2:]), "living_dag_executed_after_unconfirmed_payment")
        self.check_living_state(paid=False)
        self.check_no_persisted_codes()
        marker = {"plan_id": response["plan_id"], "old_request_id": response["request_id"], "phase": "prepared_not_paid"}
        with (self.directory / "group9-prepared.json").open("x", encoding="utf-8") as handle:
            json.dump(marker, handle, ensure_ascii=False)
        self.emit("child_prepare_completed", **marker)

    def recover_group_9(self):
        with (self.directory / "group9-prepared.json").open("r", encoding="utf-8") as handle:
            marker = json.load(handle)
        self.start_bank(9, existing=True)
        self.emit("parent_reopened_after_child_exit", marker=marker)
        self.check_living_state(paid=False)
        plan_id = marker["plan_id"]
        request = query(self.database, "SELECT status FROM requests WHERE request_id=?", (marker["old_request_id"],))
        require(request == [{"status": "cancelled"}], "restart_did_not_invalidate_pending")
        response = self.bank.resume_plan(plan_id)
        self.emit("resume_without_recovery", response=response)
        require(response.get("status") == "rejected" and response.get("reason") == "recovery_authorization_required", "resume_without_new_authorization")
        review = self.bank.prepare_recovery(plan_id)
        self.emit("recovery_prepared", response=review, state=ledger(self.database))
        self.status(review, "pending")
        require(review.get("tier") == "none" and review.get("intent") == "recover_plan", "recovery_control_tier_or_intent")
        operation = review.get("operation", {})
        require(operation.get("user_id") == "alice" and operation.get("plan_id") == plan_id, "recovery_identity_or_plan")
        require(operation.get("completed_steps") == ["catalog"] and operation.get("remaining_steps") == [row[0] for row in PLAN[1:]], "recovery_completed_or_remaining")
        operations = operation.get("operations", [])
        require(len(operations) == 5, "recovery_operation_count")
        pay_operations = [row for row in operations if row.get("intent") == "place_order"]
        require(len(pay_operations) == 1 and exact(pay_operations[0].get("params"), PLAN[1][2]), "recovery_payment_parameters")
        require(sorted(row.get("intent") for row in operations) == sorted(row[1] for row in PLAN[1:]), "recovery_extra_or_missing_tools")
        code = review.get("recovery_code")
        require(isinstance(code, str) and re.fullmatch(r"[0-9]{6}", code) is not None, "invalid_recovery_code")
        expiry = datetime.fromisoformat(review["expires_at"])
        require(expiry.tzinfo is not None and NOW < expiry <= NOW + timedelta(minutes=5), "invalid_recovery_lifetime")
        self.codes.add(code)
        before = business(self.database)
        authorized = self.bank.confirm_recovery(review["review_id"], code)
        self.emit("fixed_recovery_consent", response=authorized, state=ledger(self.database))
        self.status(authorized, "success")
        require(authorized.get("reason") == "recovery_authorized", "recovery_consent_not_saved")
        self.require_unchanged(before)
        pending = self.bank.resume_plan(plan_id)
        self.emit("recovered_new_payment_pending", response=pending)
        require(pending.get("request_id") != marker["old_request_id"], "restart_reused_old_request")
        self.confirm(pending, "place_order", PLAN[1][2])
        self.check_living_state(paid=True)
        request_id = pending["request_id"]
        order = ledger(self.database)["orders"][0]
        expected = {"order_id": request_id, "user_id": "alice", "budget_id": "birthday", "account_id": "alice-main",
                    "service_id": "flower-basic", "card_id": "card-alice-main", "event_date": DATE,
                    "amount_cents": 12900, "status": "paid", "shanghai_date": NOW.date().isoformat()}
        require(all(exact(order.get(key), value) for key, value in expected.items()), "paid_order_exact_fields")
        response = self.bank.resume_plan(plan_id)
        self.emit("living_dag_completed", response=response)
        self.status(response, "success")
        plan = self.bank.get_plan(plan_id)["plan"]
        self.plan_gate(plan)
        require(all(step["status"] == "success" for step in plan["steps"]), "living_dag_unfinished_node")
        require(exact(plan["steps"][-1]["result"]["actual_expense_cents"], 18870), "living_dag_bill_result")
        require(request_id in json.dumps(plan["committed_effects"], ensure_ascii=False), "paid_order_missing_committed_effect")
        require(query(self.database, "SELECT status FROM requests WHERE request_id=?", (request_id,)) == [{"status": "success"}], "paid_request_not_success")
        audit = query(self.database, "SELECT request_id,intent,event,result,step_id,plan_id FROM audit_log WHERE request_id=? AND event='executed'", (request_id,))
        require(len(audit) == 1 and audit[0]["intent"] == "place_order" and audit[0]["result"] == "success" and audit[0]["step_id"] == "pay" and audit[0]["plan_id"] == plan_id, "paid_audit_node_atomic_correspondence")
        before = business(self.database)
        self.bank.confirm(request_id, pending["confirmation_code"])
        self.bank.cancel()
        self.require_unchanged(before)
        self.finish_group()


def choose_directory(value):
    if value is None:
        value = "evidence/six-live-" + datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:8]
    path = (ROOT / value).resolve()
    require(path.is_relative_to((ROOT / "evidence").resolve()) and path.name.startswith("six-live-"), "output_must_be_new_six_live_evidence_directory")
    return path


def source_hashes():
    paths = (ROOT / "src/SIX_SCENARIO_API.md", ROOT / "src/CONTEXT_API.md", ROOT / "docs/39-six-live-matrix.md", Path(__file__).resolve())
    return {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}


def main():
    parser = argparse.ArgumentParser(description="Independent bounded real-model/Docker acceptance; creates only a new evidence run.")
    parser.add_argument("--runtime", required=True)
    parser.add_argument("--output-dir")
    parser.add_argument("--max-calls", type=int, default=30)
    parser.add_argument("--groups", default="1,2,3,4,5,6,7,8,9")
    parser.add_argument("--internal-prepare9", action="store_true", help=argparse.SUPPRESS)
    arguments = parser.parse_args()
    require(1 <= arguments.max_calls <= 30, "max_calls_must_be_1_to_30")
    groups = [int(value) for value in arguments.groups.split(",")]
    require(bool(groups) and groups == sorted(set(groups)) and all(1 <= value <= 9 for value in groups), "invalid_group_selection")
    directory = choose_directory(arguments.output_dir)
    if arguments.internal_prepare9:
        require(directory.is_dir() and (directory / "manifest.json").is_file(), "internal_phase_requires_existing_owned_run")
    else:
        directory.mkdir(parents=True, exist_ok=False)
        manifest = {"kind": "independent_six_live", "max_calls": arguments.max_calls, "groups": groups,
                    "source_sha256": source_hashes(), "simulated": True, "fixed_shanghai_clock": NOW.isoformat(),
                    "author_read_implementation": False, "retries": 0, "cost": "unknown"}
        with (directory / "manifest.json").open("x", encoding="utf-8") as handle:
            json.dump(manifest, handle, ensure_ascii=False, indent=2)
    harness = Harness(directory, arguments.runtime, arguments.max_calls)
    exit_code = 0
    failure = None
    try:
        if arguments.internal_prepare9:
            harness.prepare_group_9()
        else:
            for group in groups:
                if group != 9:
                    harness.run_group(group)
                    continue
                harness.close()
                harness.group = 9
                harness.emit("child_prepare_launch", no_confirmation_codes_in_process_arguments=True)
                child = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--runtime", str(Path(arguments.runtime).resolve()),
                                        "--output-dir", str(directory), "--max-calls", str(arguments.max_calls),
                                        "--groups", "9", "--internal-prepare9"],
                                       capture_output=True, timeout=240)
                harness.emit("child_prepare_exit", exit_code=child.returncode, stdout_bytes=len(child.stdout), stderr_bytes=len(child.stderr))
                require(child.returncode == 0, "prepare_child_failed_see_safe_journal")
                harness.recover_group_9()
    except Exception as exception:
        exit_code = 1
        failure = {"type": type(exception).__name__, "code": exception.code if isinstance(exception, AcceptanceFailure) else "unexpected_safe_exception"}
        harness.emit("run_stopped", failure=failure)
    finally:
        try:
            harness.close()
        except Exception as exception:
            exit_code = 1
            failure = {"type": type(exception).__name__, "code": "cleanup_not_confirmed"}
            harness.emit("cleanup_failed", failure=failure)
    if not arguments.internal_prepare9:
        events = harness.events()
        completed = [row["group"] for row in events if row.get("event") == "group_passed"]
        calls = [row for row in events if row.get("event") == "model_call_finished"]
        report = {"status": "passed" if exit_code == 0 else "failed", "groups_requested": groups,
                  "groups_passed": completed, "groups_not_passed": [group for group in groups if group not in completed],
                  "propose_calls_started": harness.call_count(),
                  "transport_attempts_reported": sum(row["metadata"]["request_attempted"] is True for row in calls),
                  "model_calls": calls, "failure": failure, "cost": "unknown", "retries": 0,
                  "source_sha256_after": source_hashes(), "real_human_verification": "not_performed"}
        with (directory / "report.json").open("x", encoding="utf-8") as handle:
            json.dump(safe(report), handle, ensure_ascii=False, indent=2, allow_nan=False)
        print(json.dumps({"status": report["status"], "groups_passed": completed, "propose_calls_started": report["propose_calls_started"],
                          "report": str(directory / "report.json")}, ensure_ascii=False))
    return exit_code


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AcceptanceFailure as exception:
        print(json.dumps({"status": "failed", "safe_code": exception.code}, ensure_ascii=False))
        raise SystemExit(2)
    except Exception as exception:
        print(json.dumps({"status": "failed", "exception_type": type(exception).__name__, "safe_code": "initialization_or_report_failure"}, ensure_ascii=False))
        raise SystemExit(2)
