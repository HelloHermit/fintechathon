"""有限次真实模型集成检查。使用全新模拟账本，不触碰日常演示数据。"""

import json
import sys
import uuid
from datetime import datetime
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))
from src.bank import BankService
from src.model import ModelClient, ModelError
from src.storage import SHANGHAI


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    try:
        model = ModelClient()
    except ModelError as error:
        print(str(error))
        print("真实模型检查未运行；先在本机运行配置脚本。")
        return 2
    database_path = PROJECT_ROOT / "tests" / ".runs" / ("live-" + uuid.uuid4().hex + ".db")
    bank = BankService(database_path)
    evidence = {"mode": "real_model_integration_check", "simulated_bank": True,
                "timestamp": datetime.now(SHANGHAI).isoformat(), "checks": [],
                "confirmation": "测试脚本仅对事先指定的模拟用户、目标和金额进行明确确认；不是生产自动批准。"}

    def ask(text, intent, expected_params=None, needs_confirmation=False):
        response = bank.handle_text(text, model)
        record = {"input": text, "expected_intent": intent,
                  "response": {key: value for key, value in response.items() if key != "confirmation_code"},
                  "usage": dict(getattr(model, "last_usage", {}))}
        evidence["checks"].append(record)
        if response.get("status") == "failed":
            print("模型失败类型：", response.get("model_error_code", "unknown"), "HTTP状态：", response.get("http_status"))
        if response.get("intent") != intent:
            raise AssertionError("模型未产生所期待的意图，停止后续检查")
        if needs_confirmation:
            if response["status"] != "pending":
                raise AssertionError("黄档未返回等待确认，停止检查")
            actual_params = response["operation"]["params"]
            if expected_params != actual_params:
                raise AssertionError("候选目标/金额不符合事先指定的模拟用例，未确认")
            completed = bank.confirm(response["request_id"], response["confirmation_code"])
            record["after_explicit_test_confirmation"] = completed
            if completed["status"] != "success":
                raise AssertionError("确认后的模拟操作未成功")
            return completed
        if response["status"] != "success":
            raise AssertionError("绿色工具未成功，停止后续检查")
        return response

    exit_code = 0
    try:
        bill = ask("这个月已经花了多少？", "analyze_bills")
        if bill["data"]["actual_expense_cents"] != 5970:
            raise AssertionError("账单金额不符合夹具")
        subscription = ask("我有哪些自动扣款？", "query_subscriptions", {}, True)
        if subscription["data"]["future_expected_cents"] != 5970:
            raise AssertionError("订阅金额不符合夹具")
        ask("请取消我的视频会员。", "cancel_subscription", {"subscription_id": "sub-video"}, True)
        bill = ask("这个月实际已经花了多少？", "analyze_bills")
        if bill["data"]["actual_expense_cents"] != 5970:
            raise AssertionError("取消订阅改变了历史支出")
        ask("从我的主账户给已经登记的小王转100元。", "transfer",
            {"account_id": "alice-main", "contact_id": "wang", "amount_cents": 10000}, True)
        evidence["status"] = "success"
        print("真实模型三场景检查成功；所有资金/订阅动作仍为模拟。")
    except (AssertionError, KeyError, TypeError):
        evidence["status"] = "failed"
        evidence["reason"] = "实际意图、目标、确认状态或账本结果不符合指定用例；已停止后续检查。"
        print(evidence["reason"])
        exit_code = 1
    finally:
        evidence["audit"] = bank.audit_events()
        bank.close()
        output_folder = PROJECT_ROOT / "evidence"
        output_folder.mkdir(exist_ok=True)
        destination = output_folder / "real-model-integration.json"
        destination.write_text(json.dumps(evidence, ensure_ascii=False, indent=2), encoding="utf-8")
        print("脱敏证据：", destination)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
