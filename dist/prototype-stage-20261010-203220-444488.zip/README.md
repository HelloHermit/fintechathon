# FinTechathon · 模拟银行 AI 助手

2026-10-10：Python + SQLite 原型已实现，账单分析、订阅管理、小额转账的**离线代码链路已实际复演**。所有账户、资金、平台操作都是模拟。队长已选DeepSeek V4.1 Flash（API模型名deepseek-flash），本轮允许上限一亿token；适配器已写，本机密钥已配置；真实请求到达DeepSeek但返回HTTP401认证失败，三个场景完整链路仍未通过。

## 在本机启动

```powershell
cd C:\fintechathon
.\scripts\start.ps1
```

脚本会找到可用 Python 3.10+。无需安装第三方业务依赖。模型缺配置时明确报错，仍可使用 CLI 的离线候选调试入口。详细[启动与接口说明](src/README.md)、[本机模型配置](docs/model-configuration.md)、[独立测试约定](src/PUBLIC_API.md)。密钥在本机输入，不发聊天、不提交仓库。

```powershell
# 使用任一可用 Python 3.10+；队长本机捆绑路径如下
$Python = 'C:\Users\KindHermit\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
& $Python scripts/demo.py
& $Python -m unittest discover -s tests -p 'test_*.py' -v
```

`demo.py` 创建独立模拟数据库，不重置日常运行数据，输出到 [脱敏复演回执](evidence/three-scenario-demo.json)。它直接提交候选，不调用真实模型，不可把这段演示说成 AI 接入成功。

## 当前可核对的结果

| 项目 | 实际状态 |
|---|---|
| 实际账单 | 990+1990+2990=5970 分，即59.70元；与未来预计分开 |
| 订阅查询与取消 | 查询黄档，未确认不披露列表；取消视频后历史5970分保留、未来预计2980分 |
| 模拟转账 | 100元明确确认后一次执行，双方余额/流水/成功日志同事务；重放拒绝 |
| 安全边界 | 固定白名单/严格参数/归属/上海日累计/五分钟确认/持久化三错锁十分钟 |
| 候选任务图 | 校验依赖和循环；每个黄档步骤单独确认；中断/接管停止未完成节点 |
| 独立验收 | 隔离子代理只读规格和公开接口编写，结果见[独立报告](docs/09-independent-acceptance.md) |
| 真实模型 | 已选DeepSeek并本机配置，联网调用返回HTTP401；需核对有效API密钥后复测 |
| 红档MFA与隔离 | 尚未完成，红档拒绝；Docker引擎未连通，见[可行性证据](docs/10-feasibility-evidence.md) |
| 补偿回退、正式渠道、人工验收 | 尚未完成；CLI用于原型调试，已成功转账不自动撤回 |

## 规则与交付

[AGENTS.md](AGENTS.md) 是当前项目契约；[权限v3](docs/01-permission-tiers.md)、[用户故事](docs/02-user-stories.md) 是业务验收依据。[技术说明](docs/11-technical-note.md)、[校内展示草稿](docs/12-school-demo-draft.md)、[执行记录](接下来怎么做.md)、[核对清单](今日核对清单.md) 按实际证据更新。

内部验收仍为北京时间2026-10-11 20:00，19:00冻结新增功能；校内通知未知。赛事提交节点沿用[需求来源记录](spec/competition-requirements.md)，正式提交前复核。v2曾三人确认，v3尚未取得队友同步/人工验收证据。未经另行授权不公开仓库、不push、不部署、不发消息。
